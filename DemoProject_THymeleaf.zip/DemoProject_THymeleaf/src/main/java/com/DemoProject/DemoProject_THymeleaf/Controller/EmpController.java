package com.DemoProject.DemoProject_THymeleaf.Controller;

import javax.mail.MessagingException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import com.DemoProject.DemoProject_THymeleaf.Entity.Employee;
import com.DemoProject.DemoProject_THymeleaf.Service.EmailService;
import com.DemoProject.DemoProject_THymeleaf.Service.EmployeeService;

@Controller
public class EmpController {
	@Autowired
	private EmailService emailService;

	
	@Autowired
	public EmployeeService employeeService;

	@GetMapping("/")
	public String showPage(Model model) {
		model.addAttribute("listEmployees", employeeService.getallEmployees());
		return "index";
	}

	@GetMapping("/showNewEmployeeForm")
	public String addNewEmployee(Model model) {
		Employee employee= new Employee();
		model.addAttribute("employee", employee);
		return "new_employee";
	}

	@PostMapping("/saveEmployee")
	public String saveEmployee(@ModelAttribute("employee") Employee employee ) throws MessagingException {
		employeeService.saveEmployee(employee);
		emailService.sendEmail(employee);
		System.out.println("mail sent");
		return "redirect:/";
	}

	@PostMapping("/updateEmployee")
	public String updateEmployee(@ModelAttribute("employee") Employee employee ) {
		employeeService.updateEmployee(employee);
		return "redirect:/";
	}
	
	@GetMapping("/showFormForUpdate/{id}")
	public String showFormForUpdate(@PathVariable(value = "id") Long id, Model model) {
		Employee employee = employeeService.getEmployeeById(id);
		model.addAttribute("employee", employee);
		return "update_employee";

	}

	@GetMapping("/deletebyid/{id}")
	public String deleteEmployee(@PathVariable(value = "id") Long id) {
		employeeService.deleteEmployeeById(id);
		return "redirect:/";
	}
}
