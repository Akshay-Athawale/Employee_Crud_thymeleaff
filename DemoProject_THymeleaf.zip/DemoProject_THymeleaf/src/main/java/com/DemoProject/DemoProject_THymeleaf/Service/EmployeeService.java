package com.DemoProject.DemoProject_THymeleaf.Service;

import java.util.List;

import com.DemoProject.DemoProject_THymeleaf.Entity.Employee;
import com.DemoProject.DemoProject_THymeleaf.Request.EmployeeDto;
import com.DemoProject.DemoProject_THymeleaf.Response.EmployeeResponse;

public interface EmployeeService {

	public List<Employee> getallEmployees();

	void saveEmployee(Employee employee);

	Employee getEmployeeById(Long id);

	Employee deleteEmployeeById(Long id);

	void updateEmployee(Employee employee);
}
