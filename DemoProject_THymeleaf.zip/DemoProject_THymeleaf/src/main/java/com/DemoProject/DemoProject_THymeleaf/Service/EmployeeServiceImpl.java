package com.DemoProject.DemoProject_THymeleaf.Service;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.DemoProject.DemoProject_THymeleaf.Entity.Employee;
import com.DemoProject.DemoProject_THymeleaf.Repository.EmployeeRepository;

@Service
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	public EmployeeRepository employeeRepository;

	@Override
	public List<Employee> getallEmployees() {
		return employeeRepository.findAll();

	}

	@Override
	public void saveEmployee(Employee employee) {
		if (employee!=null) {
			employeeRepository.save(employee);
		}
		
	}

	@Override
	public Employee getEmployeeById(Long id) {
		Optional<Employee> optional = employeeRepository.findById(id);
		Employee employee =new Employee();
		employee=null;
		if (optional.isPresent()) {
			employee = optional.get();
		} else {
			throw new RuntimeException("Employee not found by id" + id);
		}
		return employee;

	}

	@Override
	public Employee deleteEmployeeById(Long id ) {
		Employee employee = new Employee();
	     employeeRepository.deleteById(id);
		return employee;

	}

	@Override
	public void updateEmployee(Employee employee) {
		employeeRepository.saveAndFlush(employee);
		
	}

}
