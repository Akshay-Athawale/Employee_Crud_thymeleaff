package com.DemoProject.DemoProject_THymeleaf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoProjectTHymeleafApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoProjectTHymeleafApplication.class, args);
	}

}
