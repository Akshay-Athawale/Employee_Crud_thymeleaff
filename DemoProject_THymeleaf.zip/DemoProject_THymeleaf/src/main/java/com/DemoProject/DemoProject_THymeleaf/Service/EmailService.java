package com.DemoProject.DemoProject_THymeleaf.Service;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import com.DemoProject.DemoProject_THymeleaf.Entity.Employee;

@Service
public class EmailService {

	
	@Autowired
	private JavaMailSender sender;

	public void sendEmail(Employee employee) throws MessagingException {
		MimeMessage message = sender.createMimeMessage();
		MimeMessageHelper helper = new MimeMessageHelper(message);
		String mailcontent = "<p> registration successfull with below details </p>";
		mailcontent += "<p><b> name:</b> " + employee.getName() + "</p>";
		mailcontent += "<p><b> mobile: </b> " + employee.getMobNo() + "</p>";
		mailcontent += "<p><b> gender: </b> " + employee.getGender() + "</p>";
		mailcontent += "<p><b> city: </b> " + employee.getCity() + "</p>";
		mailcontent += "<p><b> status: </b> " + employee.getMarried() + "</p>";

		String sub = "mail to test";
		helper.setTo(employee.getEmail());
		helper.setText(mailcontent, true);
		helper.setSubject(sub);

		sender.send(message);
	}
}
